#!/usr/bin/env python

import checker

CHECK_OUTPUT_PROGRAM_NAME = 'check_output.py'

if __name__ == '__main__':
    checker.check_output(CHECK_OUTPUT_PROGRAM_NAME)
