#!/usr/bin/env python

import checker

if __name__ == '__main__':
    checker.check_input()
