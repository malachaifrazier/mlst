package main

import (
	"mlst"
)

func main() {
	mlst.CheckInput()
}
