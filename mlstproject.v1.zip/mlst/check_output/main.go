package main

import (
	"mlst"
)

const (
	checkOutputProgramName = "check_output"
)

func main() {
	mlst.CheckOutput(checkOutputProgramName)
}
